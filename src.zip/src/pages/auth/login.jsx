import React, { useState } from 'react'
// import { validation } from '../../utils/validation';




const Login = () => {


    const [formValues, setFormValues] = useState({
        email: '',
        password: '',
    });

    const [errors, setErrors] = useState({
        email: '',
        password: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValues({
            ...formValues,
            [name]: value,
        });

        // Clear error message for the field being edited
        setErrors({
            ...errors,
            [name]: '',
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // let isValid = true;
        // const validationErrors = validation(formValues);
        // console.log(validationErrors, "er")
        // setErrors(validationErrors);

        // if (Object.keys(validationErrors).length === 0) {
        //     // Form is valid, proceed with form submission
        //     console.log('Form submitted successfully!', formValues);
        // }

    };


    return (
        <div>
            <h2>Custom Form Validation</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Email:</label>
                    <input
                        type="text"
                        name="email"
                        value={formValues.email}
                        onChange={handleChange}
                    />
                    {errors.email && <span style={{ color: 'red' }}>{errors.email}</span>}
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formValues.password}
                        onChange={handleChange}
                    />
                    {errors.password && <span style={{ color: 'red' }}>{errors.password}</span>}
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default Login