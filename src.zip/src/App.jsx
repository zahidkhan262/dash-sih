import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './layout/home'
import SideBar from './layout/sidebar/sidebar'
import { useState } from 'react'
import './App.css'
import Header from './layout/header'
import Login from './pages/auth/login'
import Register from './pages/auth/register'
import { ErrorBoundary } from 'react-error-boundary'
function App() {

  const [isOpen, setIsOpen] = useState(true)
  const [error, setLogError] = useState('')


  function fallbackRender({ error, resetErrorBoundary }) {
    // Call resetErrorBoundary() to reset the error boundary and retry the render.

    return (
      <div role="alert">
        <p>Something went wrong:</p>
        <pre style={{ color: "red" }}>{error.message}</pre>
        <p>{error}</p>
      </div>
    );
  }


  return (
    <ErrorBoundary
      fallbackRender={fallbackRender}
    >
      <BrowserRouter>
        <Header />
        <SideBar setIsOpen={setIsOpen} isOpen={isOpen}>
          <Routes>
            <Route path="/home" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </Routes>
        </SideBar>
      </BrowserRouter>
    </ErrorBoundary>
  )
}

export default App
