import { FaHome, FaUser, FaMoneyBill } from "react-icons/fa";
import { AiTwotoneFileExclamation } from "react-icons/ai";

export const routes = [
    {
        path: '/home',
        name: "Home",
        icon: FaHome,
    },
    {
        path: "/login",
        name: "Login",
        icon: FaUser,
    },
    {
        path: "/register",
        name: "Register",
        icon: FaUser,
    },
    {
        path: '/cms',
        name: "CMS",
        icon: AiTwotoneFileExclamation,
        subRoutes: [
            {
                path: '/blog',
                name: "Blog",
                icon: FaMoneyBill,
                subMenus: [
                    {
                        path: '/blogs',
                        name: "Blogs",
                        icon: FaUser,
                    },
                    {
                        path: '/category',
                        name: "Category",
                        icon: FaUser,
                    },
                    {
                        path: '/author',
                        name: "Author",
                        icon: FaUser,
                    },
                ],
            },
            {
                path: "/home-banner",
                name: "Home Banner",
                icon: FaUser,
            },
            {
                path: "/press-release",
                name: "Press Release",
                icon: FaUser,
            },
            {
                path: "/merchant-stories",
                name: "Merchant Stories",
                icon: FaUser,
            },
            {
                path: "/contact-location",
                name: "Contact Location",
                icon: FaUser,
            },
            {
                path: "/leads",
                name: "Leads",
                icon: FaUser,
            },
        ],
    },
    {
        path: "/settings",
        name: "Setting",
        icon: FaUser,
    },
];
