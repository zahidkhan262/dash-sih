import React from 'react'
import { useLocation } from 'react-router-dom'
import useActiveRouteName from '../../utils/useCurrentPathName';
import { routes } from '../../utils/data';

const Header = () => {
    const activePath = useActiveRouteName(routes);
    console.log(activePath)

    return (
        <div className='d-flex justify-content-between align-items-center p-3 bg-dark text-white '>
            <div className="log">logo</div>
            <div className="page-name">{activePath}</div>
        </div>
    )
}

export default Header