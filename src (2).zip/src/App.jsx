import { BrowserRouter } from 'react-router-dom'

import { useState } from 'react'
import './App.css'
import Routing from './routing/routing'
function App() {

  





  return (
  
      <BrowserRouter>
        <Routing  />
      </BrowserRouter>
  )
}

export default App
